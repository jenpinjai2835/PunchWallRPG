# Gilded Grove — three-model sample

Included: 03_Shipping_Crate, 09_Coin_Stack, and 12_Crystal_Cluster.
Each model has one FBX, one GLB, and one portrait. The two formats contain the
same geometry. Teal, Ember, and Amethyst are palette variants, not extra models.
This sample contains no other models, full-pack renders, Blender scenes, or
generator source. It contains no shop, economy, animation, or gameplay scripts.

Unzip all files, then open a separate Roblox Studio test place. Choose File >
Import and start with one FBX. Check warnings, orientation, size, and textures.
For stationary decoration, enable Anchored. Keep Import Only As Model enabled
when retaining separate parts. You may disable Upload to Roblox for a local
trial. Source coordinates are Z up, -Y front; one unit is intended as one stud.
Compare dimensions with manifest.json. Native File > Import compatibility has
not been verified; a Studio geometry preview is a separate check. No uploaded
Roblox asset IDs or .rbxm files are included. All six sample export files have
passed Blender roundtrip import checks. Performance depends on your scene.

See https://create.roblox.com/docs/studio/importer for current import controls.
SHA256SUMS.txt records the checksum of every other file in this ZIP.

## ภาษาไทย

ตัวอย่างนี้มีเฉพาะ Shipping Crate, Coin Stack และ Crystal Cluster รวม 3 โมเดล
แต่ละชิ้นมี FBX, GLB และภาพตัวอย่าง พร้อมพื้นผิว 3 ชุดสีซึ่งไม่นับเป็นโมเดลเพิ่ม
ไม่มี source ของแพ็กเต็ม ระบบร้านค้า เงิน animation หรือสคริปต์เกม
แตกไฟล์ให้ครบ แล้วลอง File > Import ในฉากทดสอบแยก ตรวจคำเตือน ขนาด สี
ตำแหน่ง และการชนก่อนใช้จริง ไฟล์ผ่านการนำเข้ากลับใน Blender แล้ว แต่ยังไม่ผ่าน
การตรวจเมนู File > Import ใน Studio และไม่มี asset ID หรือไฟล์ .rbxm ให้
